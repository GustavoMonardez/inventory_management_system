package inventory_management_system;

public class Controller {
}
